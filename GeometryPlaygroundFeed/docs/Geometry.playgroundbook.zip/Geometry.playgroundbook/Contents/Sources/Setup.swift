import UIKit
import PlaygroundSupport


public func _setup() {
    let view = GridPaperView()
    PlaygroundPage.current.liveView = view
}
