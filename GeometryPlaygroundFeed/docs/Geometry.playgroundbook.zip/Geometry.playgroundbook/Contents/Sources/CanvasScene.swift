//
//  CanvasScene.swift
//  Geometry
//
//  Created by Daniel Budd on 24/08/2016.
//  Copyright © 2016 Daniel Budd. All rights reserved.
//

import SpriteKit

public class CanvasScene : SKScene {
    
    /*func addShape(pen: Pen){
        self.addChild(ShapeSK(pen: pen).node)
    
    }*/
    
    
    override public func didMove(to view: SKView) {
        super.didMove(to: view)
        
        
    }
    
    
    override public func update(_ currentTime: TimeInterval) {
        super.update(currentTime)
    }
    
}
