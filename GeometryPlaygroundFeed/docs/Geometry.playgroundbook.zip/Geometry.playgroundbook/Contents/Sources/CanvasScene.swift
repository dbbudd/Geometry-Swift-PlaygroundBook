//
//  CanvasScene.swift
//  Geometry
//
//  Created by Daniel Budd on 24/08/2016.
//  Copyright © 2016 Daniel Budd. All rights reserved.
//

import SpriteKit

public class CanvasScene : SKScene {
    
    override public func didMove(to view: SKView) {
        super.didMove(to: view)
    }
    
    override public func update(_ currentTime: TimeInterval) {
        super.update(currentTime)
    }
    
}
